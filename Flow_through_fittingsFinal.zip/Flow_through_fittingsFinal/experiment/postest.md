## Post test
<br>
Q 1. What is Darcy-Weisbach formula for heat loss due to friction? Where, f = Darcy's coefficient of friction <br>
a. h<sub>f</sub> = (f l V<sup>2</sup>) / (g d)<br>
b. h<sub>f</sub> = (f l V<sup>2</sup>) / (2 g d)<br>
c. h<sub>f</sub> = (16 f l V<sup>2</sup>) / (2 g d)<br>
<b>d. h<sub>f</sub> = (4 f l V<sup>2</sup>) / (2 g d)</b><br><br>

Q 2. Minor losses do not make any serious effect in <br>
<b>a. Long pipes</b><br>
b. Short pipes<br>
c. Both the short as well as long pipes<br>
d. Cannot say<br>

Q 3. What is the effect of change in Reynold's number on friction factor in turbulent flow?<br>
a. As the Reynold's number increases the friction factor increases in turbulent flow<br>
b. Change in Reynold's number does not affect the friction factor in turbulent flow<br>
<b>c. As the Reynold's number increases the friction factor decreases in turbulent flow</b><br>
d. Unpredictable<br>

Q 4. The friction factor in fluid flowing through pipe depends upon <br>
a. Reynold's number<br>
b. Relative roughness of pipe surface</b><br>
<b>c. Both a and b<br>
d. None of the above <br>

Q 5. The head loss through fluid flowing pipe due to friction is <br>
a. The minor loss<br>
<b>b. The major loss</b><br>
c. Both a and b<br>
d. None of these<br>

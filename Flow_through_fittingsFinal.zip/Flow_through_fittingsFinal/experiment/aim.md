<ul>
  <li>
    To determine the frictional losses encountered in a hydraulically smooth pipe under laminar and turbulent flow situations.
  </li>
  <li>
    To determine the effect of Reynolds number on Fanning friction factor for laminar and turbulent flow situations in a hydraulically smooth pipe. Verify the correlations for laminar flow and turbulent flow.
  </li>
</ul>
